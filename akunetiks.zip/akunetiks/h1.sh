#!/bin/bash
filename='prv2'
n=1
while read line; do
# reading each line
python3 autosub.py $line
rm -rf domains.txt
n=$((n+1))
done < $filename
