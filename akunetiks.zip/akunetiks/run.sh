#!/bin/bash

bash ./h1.sh

while true; do

	python3 send.py
	docker system prune -a --volumes -f

	sleep 60
	
done
