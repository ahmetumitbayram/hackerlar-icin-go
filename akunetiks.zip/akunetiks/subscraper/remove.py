import platform

oss = str(platform.system())

if oss == "Windows":
    print("a")
else:
    print("b")