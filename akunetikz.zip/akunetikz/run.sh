#!/bin/bash

bash ./h1.sh

while true; do

	python3 send.py
	
	sleep 600
	
done
